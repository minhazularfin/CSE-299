package com.example.shipbid;

public class Model {
    String productName, productType, StartingValue;

    public String getProductName() {
        return productName;
    }

    public String getProductType() {
        return productType;
    }

    public String getStartingValue() {
        return StartingValue;
    }
}
