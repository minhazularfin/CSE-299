package com.example.shipbid;

public class Model {
    String oName, pName, pType,pSize, pWeight, sValue, endingTime;

    public String getoName() {
        return oName;
    }

    public String getpName() {
        return pName;
    }

    public String getpType() {
        return pType;
    }

    public String getpSize() {
        return pSize;
    }

    public String getpWeight() {
        return pWeight;
    }

    public String getsValue() {
        return sValue;
    }

    public String getEndingTime() {
        return endingTime;
    }
}
